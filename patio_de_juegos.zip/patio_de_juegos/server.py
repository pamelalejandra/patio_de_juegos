from flask import Flask, render_template
app = Flask (__name__)

# 1.
@app.route('/play', methods = ['GET'])
def index1():
    return render_template('/index1.html')

#2.
@app.route('/play/<int:x>', methods = ['GET'])
def index2(x):
    return render_template('/index2.html',x=x)

#3.
@app.route('/play/<int:x>/<string:color>', methods = ['GET'])
def index3(x,color):
    style = f'style=background-color:{color}'
    return render_template('/index3.html',x=x,style=style)

if __name__ == "__main__":
    app.run(debug = True)